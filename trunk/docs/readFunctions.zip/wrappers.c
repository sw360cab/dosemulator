#include <stdlib.h> // malloc
#include <stdio.h> // fopen, fwrite, ...

#include "errlib.h"

extern char *prog;

void *Malloc (size_t nbytes)
{
  void *aptr;
  if ( (aptr = malloc(nbytes)) == NULL)
    err_sys ("(%s) error - not enough memory: malloc() failed", prog);
  return aptr;
}

FILE *Fopen (char *fname, char *mode)
{
  FILE *fp;
  if ((fp=fopen(fname,mode)) == NULL)
    err_sys ("(%s) error - can't open file %s in mode '%s'", prog, fname, mode);
  return fp;
}

void myFclose (FILE *fp, char *fname)
{
  if (fclose(fp) != 0)
    err_msg ("(%s) info - can't close file %s", prog, fname);
}

size_t Fwrite (const void *buf, size_t size, size_t count, FILE *fp)
{
  size_t actual_count;
  if ((actual_count=fwrite(buf,size,count,fp)) != count)
    err_sys ("(%s) error - fwrite() failed", prog);
  return actual_count;
}
