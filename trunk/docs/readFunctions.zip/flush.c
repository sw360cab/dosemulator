#include <stdio.h>
#include <unistd.h>

int main()
{
  printf ("E ora ...");
  fflush(stdout);
  sleep (10);
  printf ("mambo!\n");
  return 0;
}
