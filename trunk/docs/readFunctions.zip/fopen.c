#include <stdio.h>
#include "errlib.h"

int main (int argc, char *argv[])
{
  FILE *fp;

  if (argc != 2)
    err_quit ("(%s) usage: %s filename", argv[0], argv[0]);

  if ((fp=fopen(argv[1],"r")) == NULL)
  {
    perror (NULL);
    err_sys ("(%s) error - can't open file '%s'", argv[0], argv[1]);
  }

  exit (0);
}
