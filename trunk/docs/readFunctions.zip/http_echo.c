#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "errlib.h"
#include "sockwrap.h"

#define MAXBUFL 255
#define LISTENQ 15
#define HTTP_PORT 80
#define CONTLEN "Content-Length: "
#define HEAD "HTTP/1.0 200 OK\r\nConnection: close\r\nContent-Type: text/html\r\n\r\n<HTML>\r\n<HEAD><TITLE>HTTP echo</TITLE></HEAD>\r\n<BODY>\r\n<PRE>\r\n"
#define TAIL "</PRE>\r\n</BODY>\r\n</HTML>\r\n"

#define my_Writen(a,b,c) Writen(a,b,c), Writen(1,b,c)
//#define my_Writen(a,b,c) Writen(1,b,c)

char *prog;

int main (int argc, char *argv[])
{
  int listenfd, connfd;
  struct sockaddr_in servaddr, cliaddr;
  socklen_t cliaddrlen = sizeof(cliaddr);
  char buf[MAXBUFL];
  int n;
  unsigned long nbyte;

  prog = argv[0];

  listenfd = Socket (AF_INET, SOCK_STREAM, 0);

  memset (&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  servaddr.sin_port = htons(HTTP_PORT);

  Bind (listenfd, (SA*) &servaddr, sizeof(servaddr));

  Listen (listenfd, LISTENQ);

#ifdef TRACE
  printf ("(%s) socket created, waiting for connections ...\n", prog);
#endif

  for ( ; ; )
  {
    connfd = Accept (listenfd, (SA*) &cliaddr, &cliaddrlen);
#ifdef TRACE
    printf ("(%s) - new connection from client %s:%u\n", prog, inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
#endif

    // write the HTML response header
    
    my_Writen (connfd, HEAD, strlen(HEAD));

    // read the HTTP query header

    nbyte = 0;
    while ((n = Readline(connfd,buf,sizeof(buf))) > 0)
    {
      my_Writen (connfd, buf, n);
      if (strncmp(buf,CONTLEN,strlen(CONTLEN)) == 0)
      {
        if (sscanf (buf+strlen(CONTLEN), "%lu", &nbyte) != 1)
          err_quit ("(%s) error - missing no. of bytes", prog);
      }
      else if ((buf[0]=='\r') && (buf[1]=='\n'))
        break;
    }

    // read the HTTP query body (if any)
    
    while ((nbyte>0) && (n=Readn(connfd,buf,(nbyte>sizeof(buf))?sizeof(buf):nbyte)>0))
    {
      my_Writen (connfd, buf, n);
      nbyte -= n;
    }

    // write the HTML response trailer
    
    my_Writen (connfd, TAIL, strlen(TAIL));

    Close (connfd);
  }
}
